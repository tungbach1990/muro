#ifndef _C4_LOG_HPP_
#define _C4_LOG_HPP_

// FIXME - these are just dumb placeholders
#define C4_LOGF_ERR(...) fprintf(stderr, __VA_ARGS__)
#define C4_LOGF_WARN(...) fprintf(stderr, __VA_ARGS__)
#define C4_LOGP(msg, ...) printf(msg)

#endif /* _C4_LOG_HPP_ */
